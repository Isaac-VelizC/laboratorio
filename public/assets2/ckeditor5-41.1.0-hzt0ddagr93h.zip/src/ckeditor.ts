/**
 * @license Copyright (c) 2014-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

import { InlineEditor } from '@ckeditor/ckeditor5-editor-inline';

import { Alignment } from '@ckeditor/ckeditor5-alignment';
import { Bold } from '@ckeditor/ckeditor5-basic-styles';
import { CloudServices } from '@ckeditor/ckeditor5-cloud-services';
import type { EditorConfig } from '@ckeditor/ckeditor5-core';
import { Essentials } from '@ckeditor/ckeditor5-essentials';
import { ExportPdf } from '@ckeditor/ckeditor5-export-pdf';
import { FontFamily, FontSize } from '@ckeditor/ckeditor5-font';
import { Title } from '@ckeditor/ckeditor5-heading';
import { HorizontalLine } from '@ckeditor/ckeditor5-horizontal-line';
import { DataFilter } from '@ckeditor/ckeditor5-html-support';
import { AutoImage, Image } from '@ckeditor/ckeditor5-image';
import { Indent, IndentBlock } from '@ckeditor/ckeditor5-indent';
import { Mention } from '@ckeditor/ckeditor5-mention';
import { PageBreak } from '@ckeditor/ckeditor5-page-break';
import { Paragraph } from '@ckeditor/ckeditor5-paragraph';
import { RestrictedEditingMode } from '@ckeditor/ckeditor5-restricted-editing';
import { SpecialCharacters, SpecialCharactersLatin } from '@ckeditor/ckeditor5-special-characters';
import {
	Table,
	TableCellProperties,
	TableColumnResize,
	TableToolbar
} from '@ckeditor/ckeditor5-table';
import { Undo } from '@ckeditor/ckeditor5-undo';

// You can read more about extending the build with additional plugins in the "Installing plugins" guide.
// See https://ckeditor.com/docs/ckeditor5/latest/installation/plugins/installing-plugins.html for details.

class Editor extends InlineEditor {
	public static override builtinPlugins = [
		Alignment,
		AutoImage,
		Bold,
		CloudServices,
		DataFilter,
		Essentials,
		ExportPdf,
		FontFamily,
		FontSize,
		HorizontalLine,
		Image,
		Indent,
		IndentBlock,
		Mention,
		PageBreak,
		Paragraph,
		RestrictedEditingMode,
		SpecialCharacters,
		SpecialCharactersLatin,
		Table,
		TableCellProperties,
		TableColumnResize,
		TableToolbar,
		Title,
		Undo
	];

	public static override defaultConfig: EditorConfig = {
		toolbar: {
			items: [
				'bold',
				'|',
				'outdent',
				'indent',
				'|',
				'insertTable',
				'undo',
				'redo'
			]
		},
		language: 'es',
		table: {
			contentToolbar: [
				'tableColumn',
				'tableRow',
				'mergeTableCells',
				'tableCellProperties'
			]
		}
	};
}

export default Editor;
