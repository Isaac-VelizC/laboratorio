<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SystemInfo extends Model
{
    use HasFactory;
    protected $table = 'system_infos';

    protected $fillable = [
        'meta_field',
        'meta_value',
    ];
}
